#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

const int MAX_PRODUCTS = 100; // maximum number of products in inventory

struct Product {
    int id;
    char name[50];
    double price;
    int stockLevel;
};

// function prototypes
void addProduct(Product* inventory, int& numProducts);
void deleteProduct(Product* inventory, int& numProducts);
void updateProduct(Product* inventory, int numProducts);
void displayInventory(Product* inventory, int numProducts);
void displayProduct(Product* inventory, int numProducts);
void writeToFile(Product* inventory, int numProducts);
void readFromFile(Product* inventory, int& numProducts);

int main() {
    Product inventory[MAX_PRODUCTS];
    int numProducts = 0;
    char choice;

    // read existing inventory data from file
    readFromFile(inventory, numProducts);

    do {
        cout << "===== INVENTORY MANAGEMENT SYSTEM =====" << endl;
        cout << "1. Add product" << endl;
        cout << "2. Delete product" << endl;
        cout << "3. Update product" << endl;
        cout << "4. Display the inventory with product id" << endl;
        cout << "5. Display all the inventory" << endl;
        
        cout << "6. Exit" << endl;
        cout << "Enter your choice (1-5): ";
        cin >> choice;

        switch (choice) {
            case '1':
                addProduct(inventory, numProducts);
                break;
            case '2':
                deleteProduct(inventory, numProducts);
                break;
            case '3':
                updateProduct(inventory, numProducts);
                break;
            case '4':
                displayProduct(inventory, numProducts);
                break;
            case '5':
                displayInventory(inventory, numProducts);
                break;
            case '6':
                // write inventory data to file before exiting
                writeToFile(inventory, numProducts);
                break;
            default:
                cout << "Invalid choice. Please enter a number from 1 to 5." << endl;
                break;
        }

        cout << endl;
    } while (choice != '6');

    return 0;
}

void addProduct(Product* inventory, int& numProducts) {
    if (numProducts >= MAX_PRODUCTS) {
        cout << "Inventory is full. Cannot add more products." << endl;
        return;
    }

    Product newProduct;
    cout << "Enter product ID: ";
    cin >> newProduct.id;

    // check if product with same ID already exists
    for (int i = 0; i < numProducts; i++) {
        if (newProduct.id == inventory[i].id) {
            cout << "Product with ID " << newProduct.id << " already exists in inventory." << endl;
            return;
        }
    }

    cout << "Enter product name: ";
    cin.ignore();
    cin.getline(newProduct.name, 50);

    cout << "Enter product price: ";
    cin >> newProduct.price;

    cout << "Enter stock level: ";
    cin >> newProduct.stockLevel;

    inventory[numProducts] = newProduct;
    numProducts++;

    cout << "Product added to inventory." << endl;
}

void deleteProduct(Product* inventory, int& numProducts) {
    int productId;
    cout << "Enter product ID to delete: ";
    cin >> productId;

    for (int i = 0; i < numProducts; i++) {
        if (productId == inventory[i].id) {
            for (int j = i; j < numProducts - 1; j++) {
                inventory[j] = inventory[j + 1];
            }
            numProducts--;
            cout << "Product deleted." << endl;
            return;
        }
    }

    cout << "Product with ID " << productId << " not found in inventory." << endl;
}


void updateProduct(Product* inventory, int numProducts) {
    int productId;
    cout << "Enter product ID to update: ";
    cin >> productId;

    for (int i = 0; i < numProducts; i++) {
        if (productId == inventory[i].id) {
            cout << "Enter new product name (or press enter to keep current name): ";
            cin.ignore();
            cin.getline(inventory[i].name, 50);

            cout << "Enter new product price (or 0 to keep current price): ";
            cin >> inventory[i].price;

            cout << "Enter new stock level (or 0 to keep current stock level): ";
            cin >> inventory[i].stockLevel;

            cout << "Product updated." << endl;
            return;
        }
    }

    cout << "Product with ID " << productId << " not found in inventory." << endl;
}

void displayInventory(Product* inventory, int numProducts) {
    if (numProducts == 0) {
        cout << "Inventory is empty." << endl;
        return;
    }
    cout << "ID\tName\tPrice\tStock Level\tsales\tcost" << endl;
    for (int i = 0; i < numProducts; i++) {
        cout << inventory[i].id << "\t" << inventory[i].name << "\t" << inventory[i].price << "\t" << inventory[i].stockLevel << "\t"<<endl;
    }
    }


void writeToFile(Product* inventory, int numProducts) {
    ofstream outfile("inventory.txt");

    if (!outfile) {
        cout << "Error: could not open file for writing." << endl;
        return;
    }

    for (int i = 0; i < numProducts; i++) {
        outfile << inventory[i].id << "," << inventory[i].name << "," << inventory[i].price << "," << inventory[i].stockLevel << endl;
    }

    outfile.close();
    cout << "Inventory data written to file." << endl;
}

void readFromFile(Product* inventory, int& numProducts) {
    ifstream infile("inventory.txt");

    if (!infile) {
        cout << "Inventory file not found. Starting with empty inventory." << endl;
        return;
    }

    char buffer[100];
    while (infile.getline(buffer, 100)) {
        char* idString = strtok(buffer, ",");
        char* name = strtok(NULL, ",");
        char* priceString = strtok(NULL, ",");
        char* stockLevelString = strtok(NULL, ",");

        Product newProduct;
        newProduct.id = atoi(idString);
        strcpy(newProduct.name, name);
        newProduct.price = atof(priceString);
        newProduct.stockLevel = atoi(stockLevelString);

        inventory[numProducts] = newProduct;
        numProducts++;
    }

    infile.close();
    cout << "Inventory data loaded from file." << endl;
}

void displayProduct(Product* inventory, int numProducts) {
    int productId;
    cout << "Enter product ID to display: ";
    cin >> productId;

    for (int i = 0; i < numProducts; i++) {
        if (productId == inventory[i].id) {
            cout << "Product ID: " << inventory[i].id << endl;
            cout << "Product Name: " << inventory[i].name << endl;
            cout << "Product Price: " << inventory[i].price << endl;
            cout << "Product Stock Level: " << inventory[i].stockLevel << endl;
            
            return;
        }
    }

    cout << "Product with ID " << productId << " not found in inventory."<<endl;
}
